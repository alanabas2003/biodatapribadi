<?php
include_once 'header.php';
include_once 'home.php';
include_once 'footer.php';
?>